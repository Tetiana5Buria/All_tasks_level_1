export const TAG = {
    TABLE: "table",
    TR: "tr",
    TD: "td",
    TH: "th",
    THEAD: "thead",
    TBODY: "tbody",
    NUMBER: "№",
  };
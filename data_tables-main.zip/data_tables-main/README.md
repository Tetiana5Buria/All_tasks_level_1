## 📝

This repository includes a project to create data tables and uses the following technologies: HTML/CSS, JS.
The link on my project is https://tetiana5buria.github.io/data_tables/


![alt text](image.png)